| `Version` | `Update Notes`                                           |
|-----------|----------------------------------------------------------|
| 1.0.1     | Add cooldown configuration, saves to player custom data. |
| 1.0.0     | Initial Release                                          |
