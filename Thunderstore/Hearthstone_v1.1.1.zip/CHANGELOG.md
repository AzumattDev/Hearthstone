| `Version` | `Update Notes`                                                                                                                                       |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.1.1     | Caught that I forgot to account for relogging and game reboots to reapply the status effect. Fixed that.                                             |
| 1.1.0     | Add visual status effect cooldown for the hearthstone, update ServerSync internally.                                                                 |
| 1.0.3     | Bog witch update                                                                                                                                     |
| 1.0.2     | Accept PR from Rherrajan to keep InvariantCulture use consistent. Fix up PR to be valid C#, but the idea is to fix issues, and he had the right one. |
| 1.0.1     | Add cooldown configuration, saves to player custom data.                                                                                             |
| 1.0.0     | Initial Release                                                                                                                                      |
