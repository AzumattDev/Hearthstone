| `Version` | `Update Notes`                                                                                                                                       |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.3     | Bog witch update                                                                                                                                     |
| 1.0.2     | Accept PR from Rherrajan to keep InvariantCulture use consistent. Fix up PR to be valid C#, but the idea is to fix issues, and he had the right one. |
| 1.0.1     | Add cooldown configuration, saves to player custom data.                                                                                             |
| 1.0.0     | Initial Release                                                                                                                                      |
